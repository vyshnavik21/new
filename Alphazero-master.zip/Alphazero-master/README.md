# Alphazero


Implementation of megatictactoe
