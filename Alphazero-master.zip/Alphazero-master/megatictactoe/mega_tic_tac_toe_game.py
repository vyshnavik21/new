"""Class for Board State and Logic."""
from copy import deepcopy

import numpy as np
# import snoop
from game import Game


class TicTacToeGame(Game):
    """Represents the game board and its logic.
    Attributes:
        row: An integer indicating the length of the board row.
        column: An integer indicating the length of the board column.
        current_player: An integer to keep track of the current player.
        state: A list which stores the game state in matrix form.
        action_size: An integer indicating the total number of board squares.
    """
#     @snoop
    def __init__(self):
        """Initializes TicTacToeGame with the initial board state."""
        super().__init__()
        self.row = 30
        self.column = 30
        self.current_player = 1
        self.state = []
        self.action_size = self.row * self.column
        self.c=1
        # Create a n x n matrix to represent the board
        for i in range(self.row):
            self.state.append([0 * j for j in range(self.column)])

        self.state = np.array(self.state)
        self.state[15][15]=-1
        
#     @snoop
    def clone(self):
        """Creates a deep clone of the game object.
        Returns:
            the cloned game object.
        """
        game_clone = TicTacToeGame()
        game_clone.state = deepcopy(self.state)
        game_clone.current_player = self.current_player
        return game_clone
    
#     @snoop
    def play_action(self, action):
        """Plays an action on the game board.
        Args:
            action: A tuple in the form of (row, column).
        """
        x = action[1]
        y = action[2]

        self.state[x][y] = self.current_player
        self.current_player = -self.current_player
#     
    
#     @snoop
    def get_valid_moves(self, current_player):
        """Returns a list of moves along with their validity.
        Searches the board for zeros(0). 0 represents an empty square.
        Returns:
            A list containing moves in the form of (validity, row, column).
        """
#         valid_moves1 = []
        valid_moves=[]
#         for x in range(self.row):
#             for y in range(self.column):
#                 if self.state[x][y] == 0:
#                     valid_moves.append((1, x, y))
                    
           
#                 else:
#                     valid_moves.append((0, None, None))
#         return np.array(valid_moves)
           
#         print(valid_moves)
        if self.c==10:
            for i in range(900):
                
                x=np.random.randint(0,30)
                y=np.random.randint(0,30)
                valid_moves.append((1, x, y))
                self.c=self.c+1
            
        else:
            for x in range(self.row):
                for y in range(self.column):

                    if x !=0 and y!=0 and x!=29 and y!=29:
                        if self.state[x][y] ==0:
                            if self.state[x][y-1]==1 or self.state[x][y+1]==1 or self.state[x-1][y]==1 or self.state[x+1][y]==1 or self.state[x-1][y-1]==1 or self.state[x-1][y+1]==1 or self.state[x+1][y-1]==1 or self.state[x+1][y+1]==1 or self.state[x][y-1]==-1 or self.state[x][y+1]==-1 or self.state[x-1][y]==-1 or self.state[x+1][y]==-1 or self.state[x-1][y-1]==-1 or self.state[x-1][y+1]==-1 or self.state[x+1][y-1]==-1 or self.state[x+1][y+1]==-1:
                                valid_moves.append((1, x, y))
                            else:
                                valid_moves.append((0, None, None))
                        else:
                            valid_moves.append((0, None, None))
                                
                                
                
                    
                    elif x ==0 and y==0:
                        if self.state[x][y] ==0:
                            if self.state[x][y+1]==1 or self.state[x+1][y]==1 or self.state[x+1][y+1]==1 or  self.state[x][y+1]==-1 or  self.state[x+1][y]==-1 or self.state[x+1][y+1]==-1:
                                valid_moves.append((1, x, y))
                            else:
                                valid_moves.append((0, None, None))
                        else:
                            valid_moves.append((0, None, None))

                    elif x==0 and y==29:
                        if self.state[x][y] ==0:
                            if self.state[x][y-1]==1 or self.state[x+1][y]==1 or self.state[x+1][y-1]==1 or self.state[x][y-1]==-1 or  self.state[x+1][y]==-1 or self.state[x+1][y-1]==-1 :
                                valid_moves.append((1, x, y))
                            else:
                                valid_moves.append((0, None, None))
                        else:
                            valid_moves.append((0, None, None))

                    elif x==29 and y==0:
                        if self.state[x][y] ==0:
                            if self.state[x][y+1]==1 or self.state[x-1][y]==1 or self.state[x-1][y+1]==1 or  self.state[x][y+1]==-1 or self.state[x-1][y]==-1 or  self.state[x-1][y+1]==-1 :
                                valid_moves.append((1, x, y))
                            else:
                                valid_moves.append((0, None, None))
                                
                        else:
                            valid_moves.append((0, None, None))
                    elif x==29 and y==29:
                        if self.state[x][y]==0:
                            if self.state[x][y-1]==1 or  self.state[x-1][y]==1 or  self.state[x-1][y-1]==1 or  self.state[x][y-1]==-1 or  self.state[x-1][y]==-1 or  self.state[x-1][y-1]==-1 :
                                valid_moves.append((1, x, y))
                            else:
                                valid_moves.append((0, None, None))
                                
                        else:
                            valid_moves.append((0, None, None))

                    elif x ==0 and y!=0 and y!=29:
                        if self.state[x][y] ==0:
                            if self.state[x][y-1]==1 or self.state[x][y+1]==1 or  self.state[x+1][y]==1 or self.state[x+1][y-1]==1 or self.state[x+1][y+1]==1 or self.state[x][y-1]==-1 or self.state[x][y+1]==-1  or self.state[x+1][y]==-1  or  self.state[x+1][y-1]==-1 or self.state[x+1][y+1]==-1:
                                valid_moves.append((1, x, y))
                            else:
                                valid_moves.append((0, None, None))
                        else:
                            valid_moves.append((0, None, None))


                    elif y==0 and x!=0 and x!=29:
                        if self.state[x][y] ==0:
                            if self.state[x][y+1]==1 or self.state[x-1][y]==1 or self.state[x+1][y]==1  or self.state[x-1][y+1]==1 or  self.state[x+1][y+1]==1 or  self.state[x][y+1]==-1 or self.state[x-1][y]==-1 or self.state[x+1][y]==-1  or self.state[x-1][y+1]==-1 or  self.state[x+1][y+1]==-1:
                                valid_moves.append((1, x, y))
                            else:
                                valid_moves.append((0, None, None))
                        else:
                            valid_moves.append((0, None, None))



                    elif x==29 and y!=29:
                        if self.state[x][y] ==0:
                            if self.state[x][y-1]==1 or self.state[x][y+1]==1 or self.state[x-1][y]==1  or self.state[x-1][y-1]==1 or self.state[x-1][y+1]==1  or self.state[x][y-1]==-1 or self.state[x][y+1]==-1 or self.state[x-1][y]==-1 or self.state[x-1][y-1]==-1 or self.state[x-1][y+1]==-1 :
                                valid_moves.append((1, x, y))
                            else:
                                valid_moves.append((0, None, None))
                                
                        else:
                            valid_moves.append((0, None, None))



                    elif y==29 and x!=29:
                        if self.state[x][y] ==0:
                            if self.state[x][y-1]==1 or self.state[x-1][y]==1 or self.state[x+1][y]==1 or self.state[x-1][y-1]==1 or self.state[x+1][y-1]==1 or self.state[x][y-1]==-1 or  self.state[x-1][y]==-1 or self.state[x+1][y]==-1 or self.state[x-1][y-1]==-1 or  self.state[x+1][y-1]==-1:
                                valid_moves.append((1, x, y))
                            else:
                                valid_moves.append((0, None, None))
                                
                        else:
                            valid_moves.append((0, None, None))


                    else:
                        valid_moves.append((0, None, None))
    #                     print('wrong move')
    #                         if self.current_player==1:
    #                     return False

#         print(len(valid_moves))
        return np.array(valid_moves)
#     @snoop
    def check_game_over(self, current_player):
        """Checks if the game is over and return a possible winner.
        There are 3 possible scenarios.
            a) The game is over and we have a winner.
            b) The game is over but it is a draw.
            c) The game is not over.
        Args:
            current_player: An integer representing the current player.
        Returns:
            A bool representing the game over state.
            An integer action value. (win: 1, loss: -1, draw: 0
        """

        player_a = current_player
        player_b = -current_player

        # Check for horizontal marks
        for x in range(self.row):
            player_a_count = 0
            player_b_count = 0
            for y in range(self.column):
                if self.state[x][y] == player_a:
                    player_a_count += 1
                    player_b_count=0
                elif self.state[x][y] == player_b:
                    player_b_count += 1
                    player_a_count=0
                elif self.state[x][y] == 0:
                    player_b_count = 0
                    player_a_count=0
                if player_a_count == 5:
                    return True, 1
                elif player_b_count == 5:
                    return True, -1


        # Check for vertical marks
        for x in range(self.row):
            player_a_count = 0
            player_b_count = 0
            for y in range(self.column):
                if self.state[y][x] == player_a:
                    player_a_count += 1
                    player_b_count=0
                elif self.state[y][x] == player_b:
                    player_b_count += 1
                    player_a_count=0
                elif self.state[y][x] == 0:
                    player_b_count = 0
                    player_a_count=0
                if player_a_count == 5:
                    return True, 1
                elif player_b_count == 5:
                    return True, -1

         # Check for major diagonal marks
        player_a_count = 0
        player_b_count = 0
       
        player_a_check=0
        player_b_check=0
        for i in range(0,30):
            for j in range(0,30):
                if (i+1)>29 or (i+2)>29 or (i+3)>29 or (i+4)>29:
                    continue
                if (j+1)>29 or (j+2)>29 or (j+3)>29 or (j+4)>29:
                    continue
                #print(i,j)
                if (self.state[i][j]==self.state[i+1][j+1]==self.state[i+2][j+2]==self.state[i+3][j+3]==self.state[i+4][j+4]==player_a):
                    player_a_check=1
                    return True,1
                    
                if (self.state[i][j]==self.state[i+1][j+1]==self.state[i+2][j+2]==self.state[i+3][j+3]==self.state[i+4][j+4]==player_b):
                    player_b_check=1
                    return True,-1                   

        # Check for minor diagonal marks
        player_a_count = 0
        player_b_count = 0
        player_a_check=0
        player_b_check=0
        for x in range(0,30):
            for y in range(29,-1,-1):
                if ((x+4) or (x+3) or (x+2) or (x+1)) >29:
                    continue
                if ((y-4) or (y-3) or (y-2) or (y-1)) <0:
                    continue
                if (self.state[x][y] == self.state[x+1][y-1] == self.state[x+2][y-2] == self.state[x+3][y-3] == self.state[x+4][y-4]==player_a):
                    player_a_check = 1
                    return True,1
                    
                elif (self.state[x][y] == self.state[x+1][y-1] == self.state[x+2][y-2] == self.state[x+3][y-3] == self.state[x+4][y-4]==player_b):
                    player_b_check = 1
                    return True,-1
            
        

        # There are still moves left so the game is not over
        valid_moves = self.get_valid_moves(current_player)

        for move in valid_moves:
            if move[0] == 1:
#                 print(move[1],move[2])
                return False, 0

        # If there are no moves left the game is over without a winner
        return True, 0
    
#     @snoop
    def print_board(self):
        """Prints the board state."""
        print('  0  1  2  3  4  5  6  7  8  9  10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 ')
#         print('\n')        
        for x in range(self.row):
            print(x, end='')
            for y in range(self.column):
                if self.state[x][y] == 0:
                    print(' - ', end='')
                elif self.state[x][y] == 1:
                    print(' X ', end='')
                elif self.state[x][y] == -1:
                    print(' O ', end='')
            print('\n')
        print('\n')
